<?php
function xmldb_block_my_plugin_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    $result=true;
    if ($result && $oldversion < 2020110912) {

        if ($oldversion < 2020110912) {

            // Define table block_my_plugin to be created.
            $table = new xmldb_table('block_my_plugin_param');

            // Adding fields to table block_my_plugin.
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
            $table->add_field('param', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
            $table->add_field('setp',  XMLDB_TYPE_FLOAT, '10', null, XMLDB_NOTNULL, null, '1');

         
            //Добавление ключейв таблицу block_my_plugin.
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

            // Conditionally launch create table for block_my_plugin.
            if (!$dbman->table_exists($table)) {
                $dbman->create_table($table);
            }

            static $fields = array();
            global $USER, $CFG, $DB, $CFG;

            require_once($CFG->dirroot . '/mod/data/locallib.php');
            require_once($CFG->libdir . '/rsslib.php');
            require_once($CFG->libdir . '/completionlib.php');

            $paramSet = [];

            $paramSet['Ранг']=[
                '-'=>'0.1',
                'вузовский'=>'0.2',
                'муниципальный'=>'0.3',
                'региональный'=>'0.4',
                'всероссийский'=>'0.5',
                'международный'=>'0.6',
            ];
            $paramSet['Тип']=[
                '-'=>'1',
                'реферат'=>'2',
                'доклад'=>'3',
                'контрольная работа'=>'4',
                'курсовая работа'=>'5',
                'отчет по практике'=>'6',
                'зачетная книжка'=>'7',
                'олимпиада'=>'8',
                'ВКР'=>'1',
                'мастер-класс'=>'4',
                'конкурс'=>'5',
                'соревнование'=>'10',
                'чемпионат'=>'10',
                'марафон'=>'11',
                'конференция'=>'15',
                'семинар'=>'10',
                'тренинг'=>'4',
                'грант'=>'15',
                'форум'=>'5',
                'соревнования'=>'5',
            ];
            $paramSet['Результат']=[
                '-'=>'1',
                'сертификат'=>'2',
                'диплом'=>'5',
                'грамота'=>'3',
                'свидетельство'=>'3',
                'благодарность'=>'2',
                'благодарственное письмо'=>'2',
                'публикация'=>'5',
                'медаль'=>'10',
                'запись в волонтерской книжке'=>'4',
                'справка-подтверждение'=>'4',
                'информационное письмо'=>'5',
            ];
            $mas_ffeld = [];
            foreach ($paramSet as $nn_l3 => $vl) {

                foreach ($vl as $l => $p){
                    $one_fel = [
                        'name' => $nn_l3,
                        'param' => $l,
                        'setp' => $p,
                    ];
                    $mas_ffeld[] = $one_fel;
                }
            }
            $user = $DB->insert_records('block_my_plugin_param', $mas_ffeld);





            // Urating savepoint reached.
            upgrade_block_savepoint(true, 2020110912, 'my_plugin');
        }

    }

    return $result;
}
function get_fast_modinfo2($courseorid, $userid = 0, $resetonly = false) {
    // compartibility with syntax prior to 2.4:
    if ($courseorid === 'reset') {
        debugging("Using the string 'reset' as the first argument of get_fast_modinfo() is deprecated. Use get_fast_modinfo(0,0,true) instead.", DEBUG_DEVELOPER);
        $courseorid = 0;
        $resetonly = true;
    }

    // Function get_fast_modinfo() can never be called during upgrade unless it is used for clearing cache only.
    if (!$resetonly) {
    }

    // Function is called with $reset = true
    if ($resetonly) {
        course_modinfo::clear_instance_cache($courseorid);
        return null;
    }

    // Function is called with $reset = false, retrieve modinfo
    return course_modinfo::instance($courseorid, $userid);
}
