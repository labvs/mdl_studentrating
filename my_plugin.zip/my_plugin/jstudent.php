<?php
require_once('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
function rating_s($id_coorse,$id_user ){
    $all_curs=[];
    static $fields = array();
    global $USER, $CFG, $DB,$CFG;

    $params = array();
    if (!empty($id_coorse)) {
        $params = array('id' => $id_coorse);
    }else {
        print_error('unspecifycourseid', 'error');
    }


    $course = $DB->get_record('course', $params, '*', MUST_EXIST);
    $modinfo = get_fast_modinfo($course);
    $dat_curs = $modinfo->instances['data'];

    $html_rating='';

    /*сдесь цикл подкурсов их 5 в портфолио*/
    foreach ($dat_curs as $one_curs) {
        $sql_user = 'SELECT  DISTINCT r.id, r.approved, r.timecreated, r.timemodified, r.userid, r.groupid, r.dataid, u.picture,u.firstname,u.lastname,u.firstnamephonetic,u.lastnamephonetic,u.middlename,u.alternatename,u.imagealt,u.email FROM {data_content} c,{data_records} r, {user} u   WHERE c.recordid = r.id
                         AND r.dataid = :dataid
                         AND r.userid = u.id
                         AND r.userid = :userid 
                         ORDER BY r.timecreated ASC, r.id ASC
    ';
        $param_user = ['dataid' => ''.$one_curs->instance, 'userid' => ''.$id_user]; //пользователь и курс 1 3

        $allrecordids = $DB->get_records_sql($sql_user, $param_user, 0, 0);

        $data = $DB->get_record('data', array('id' => ''.$one_curs->instance));
        $fields=[];
        $rating = ['Ранг'=>[],'Тип'=>[],'Результат'=>[]];

        if (empty($fields)) {

            $fieldrecords = $DB->get_records('data_fields', array('dataid' => '' . $param_user['dataid']));

 

            /*получаем параметры*/
            $type_sql = "SELECT * FROM {block_my_plugin_param} WHERE name='Ранг'";
            $get = $DB ->get_records_sql($type_sql);
            foreach ($get as $one_gt => $pl){
                $rating['Ранг'][mb_strtolower($pl->param)] = $pl->setp;
            }

            $type_sql = "SELECT * FROM {block_my_plugin_param} WHERE name='Тип'";
            $get = $DB ->get_records_sql($type_sql);
            foreach ($get as $one_gt => $pl){
                $rating['Тип'][mb_strtolower($pl->param)] = $pl->setp;
            }

            $type_sql = "SELECT * FROM {block_my_plugin_param} WHERE name='Результат'";
            $get = $DB ->get_records_sql($type_sql);
            foreach ($get as $one_gt => $pl){
                $rating['Результат'][mb_strtolower($pl->param)] = $pl->setp;
            }


            foreach ($fieldrecords as $fieldrecord) {
                $fields[] = data_get_field($fieldrecord, $data);
            }
        }

        $param_curse = [];
        $surs_in2 = 1;
        $all_curs[$one_curs->name]=[];
        foreach ($allrecordids as $record) {   // Might be just one for the single template
            $search = '';
            foreach ($fields as $field) {
                $param_curse[$field->field->name] = highlight($search, $field->display_browse_field($record->id, 'singletemplate'));
            }

            $all_curs[$one_curs->name][$surs_in2]['param'] = $param_curse;

            $all_curs[$one_curs->name][$surs_in2]['name'] = $one_curs->name;

            /*рейтинг за курс*/
            $rang = $all_curs[$one_curs->name][$surs_in2]['param']['Ранг'];
            $rez = $all_curs[$one_curs->name][$surs_in2]['param']['Результат'];
            $typ = $all_curs[$one_curs->name][$surs_in2]['param']['Тип'];

            $cenka = $all_curs[$one_curs->name][$surs_in2]['param']['Оценка'];

            /*----Ранг-------------*/
            if($rang===''){
                $rang='-';
                $rang_cs = $rating['Ранг'][mb_strtolower($rang)];
                if($rang_cs===null){
                    $rang_cs =1;
                }
            }else if($rang===null){
                $rang_cs = 1;
            }else{
                $rang_cs = $rating['Ранг'][mb_strtolower($rang)];
                if($rang_cs===null){
                    $rang_cs =1;
                }
            }

            /*--Тип---------------*/
            if($typ===''){
                $typ='-';
                $typ_cs = $rating['Тип'][mb_strtolower($typ)];
                if($typ_cs===null){
                    $typ_cs =1;
                }
            }else if($typ===null){
                $typ_cs = 1;
            }else{
                $typ_cs = $rating['Тип'][mb_strtolower($typ)];
                if($typ_cs===null){
                    $typ_cs = 1;
                }
            }

            /*--Результат---------------*/
            if($rez===''){
                $rez='-';
                $rez_cs = $rating['Результат'][mb_strtolower($rez)];
                if($rez_cs===null){
                    $rez_cs =1;
                }
            }else if($rez===null){
                $rez_cs = 1;
            }else{
                $rez_cs = $rating['Результат'][mb_strtolower($rez)];
                if($rez_cs===null){
                    $rez_cs = 1;
                }
            }

            if($cenka===null || !$cenka || $cenka==='' || $cenka==='-' || $cenka==='0'){
                $cenka=1;
            }

            $all_curs[$one_curs->name][$surs_in2]['rating_a'] = $rang_cs * $typ_cs * $rez_cs *
                $cenka;


            $surs_in2++;
        }
        /*считеам общий за один курс*/
        $r_n=0;
        foreach ( $all_curs[$one_curs->name] as $one_c){
            $r_n += $one_c['rating_a'];
        }
        $all_curs[$one_curs->name]['rating_one'] = $r_n;
    }

    /*считаем общий рейтинг*/
    $al_eiting = 0;
    $cnt_curs =1;
    $text_rating ='';

    foreach ($all_curs as $next => $vl){
        $al_eiting +=$vl['rating_one'];
        $all_curs['all_rating'] += $vl['rating_one'];
        $cnt_curs++;
        $text_rating .= $next.' = '. $vl['rating_one'].'<br>';

    }


    $all_curs['all_rating'] =  ceil($all_curs['all_rating']*10)/10;


    $html_rating   .=  '<div class="my_plugin">';
    $html_rating   .=  $text_rating;
    $html_rating   .=  '<p> Общий рейтинг = '. $all_curs['all_rating'].' </p>';
    $html_rating   .=  '<div>';
    /* $this->content->footer = '';*/

    return $html_rating;
}
$action = required_param('action', PARAM_ALPHA);
$coorsidz        = optional_param('cours_id_ajx', '', PARAM_TEXT);
$useridz        = optional_param('user_id_ajx', '', PARAM_TEXT);
$return_html='';
if($action && $action==='userrating'){
    $return_html = rating_s($coorsidz,$useridz);
}

echo $return_html;
