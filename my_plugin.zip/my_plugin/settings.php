<?php

/**
 * Настройки нашего блока (доступны администратору)
 *
 * @package    block_my_plugin
 * @copyright  2019 MASU
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

// text1,text2, text3 берутся из файла с переводом(/lang/en/block_my_plugin))

if ($ADMIN->fulltree) {

    if($_POST && $_POST['action']==='save-settings'){
        $pst =$_POST;
      unset($pst['section'],$pst['action'],$pst['sesskey'],$pst['return']);
        $l=1;
        foreach ($pst as $item => $yy) {
            $obk =['id'=>$l, 'setp'=>$yy];
            $DB->update_record('block_my_plugin_param', $obk, $bulk=false);
            $l++;
        }
    }


	//Заголовок для типов
	$settings->add(new admin_setting_heading('block_my_plugin_head1',
              get_string('text1', 'block_my_plugin'),''));
  
	//Получение типов работ
	$db_request_type = "SELECT * FROM {block_my_plugin_param} WHERE `name`='Тип'";
	$db_result_type = $DB ->get_records_sql($db_request_type);

	$work_types = $db_result_type;


    //Получение рангов работ
	$db_request_rank = "SELECT * FROM {block_my_plugin_param} WHERE `name`='Ранг'";
	$db_result_rank = $DB ->get_records_sql($db_request_rank);

    $work_ranks = $db_result_rank;


    //Получение рангов результатов
    $db_request_result = "SELECT * FROM {block_my_plugin_param} WHERE `name`='Результат'";
    $db_sum_result = $DB ->get_records_sql($db_request_result);

    $work_results = $db_sum_result;

    $count_type = 1;
    $count_rank = 1;
    $count_result = 1;
  
	//Поля для типов в настройках
	foreach ($work_types as $work_type) {

        $setting_type = new admin_setting_configtext('block_my_plugin/type'.$count_type.'_mark',
			get_string('field/mark_header', 'block_my_plugin'),
            get_string('field/mark_description', 'block_my_plugin'),$work_type->setp, PARAM_FLOAT);
		$setting_type->visiblename = $work_type->param;
		$setting_type->description = 'Укажите вес работ';
		$settings->add($setting_type);
        $count_type+=1;   
        }
        
	//Заголовок для рангов
	$settings->add(new admin_setting_heading('block_my_plugin_head2',
        get_string('text2', 'block_my_plugin'),''));
                
	//Поля рангов в настройках
	foreach ($work_ranks as $work_rank) {

		$setting_rank = new admin_setting_configtext('block_my_plugin/rank'.$count_rank.'_mark',
            get_string('field/rank_header', 'block_my_plugin'),
            get_string('field/rank_description', 'block_my_plugin'),$work_rank->setp, PARAM_FLOAT);
		$setting_rank->visiblename = $work_rank->param;
		$setting_rank->description = 'Укажите коэффициент мероприятий';
		$settings->add($setting_rank);
        $count_rank+=1;   
        }


    //Заголовок для результат
    $settings->add(new admin_setting_heading('block_my_plugin_head3',
        get_string('text3', 'block_my_plugin'),''));

    //Поля рангов в настройках
    foreach ($work_results as $work_result) {

        $setting_result = new admin_setting_configtext('block_my_plugin/result'.$count_result.'_mark',
            get_string('field/result_header', 'block_my_plugin'),
            get_string('field/result_description', 'block_my_plugin'),$work_result->setp, PARAM_FLOAT);
        $setting_result->visiblename = $work_result->param;
        $setting_result->description = 'Укажите коэффициент результата';
        $settings->add($setting_result);
        $count_result+=1;
    }
}
