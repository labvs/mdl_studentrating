<?php

defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot . '/lib/grade/constants.php');
/*
 * Form for editing profile block settings
 * @package    block_my_plugin
 */

class block_my_plugin_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        global $CFG;
        
        // Load defaults.
        $mform->addElement('header', 'configheader', get_string('blocksettings', 'block'));


    }       
}
