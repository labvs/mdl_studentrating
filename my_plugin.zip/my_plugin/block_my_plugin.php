<?php
defined('MOODLE_INTERNAL') || die();
global $CFG;

require_once($CFG->libdir . '/pagelib.php');
global $PAGE;
$PAGE->requires->js( new moodle_url($CFG->wwwroot . '/lib/javascript.php/1623755359/lib/jquery/jquery-3.5.1.min.js') );
$PAGE->requires->js( new moodle_url($CFG->wwwroot . '/blocks/my_plugin/ajx.js') );
$PAGE->requires->css( new moodle_url($CFG->wwwroot . '/blocks/my_plugin/my_plugin.css') );

global $DB;
$table = new xmldb_table('block_my_plugin_param');
$dbman = $DB->get_manager();
if (!$dbman->table_exists($table)) {

    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
    $table->add_field('param', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
    $table->add_field('setp',  XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, '1');
    $table->add_field('cnt',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
    $dbman->create_table($table);

    static $fields = array();


    require_once($CFG->dirroot . '/mod/data/locallib.php');
    require_once($CFG->libdir . '/rsslib.php');
    require_once($CFG->libdir . '/completionlib.php');



    $paramSet = [];
    $paramSet['Тип']=[
        '-'=>'1',
        'реферат'=>'2',
        'доклад'=>'3',
        'контрольная работа'=>'4',
        'курсовая работа'=>'5',
        'отчет по практике'=>'6',
        'зачетная книжка'=>'7',
        'олимпиада'=>'8',
        'ВКР'=>'9',
        'мастер-класс'=>'4',
        'конкурс'=>'5',
        'соревнование'=>'10',
        'чемпионат'=>'10',
        'марафон'=>'11',
        'конференция'=>'15',
        'семинар'=>'10',
        'тренинг'=>'4',
        'грант'=>'15',
        'форум'=>'5',
        'соревнования'=>'5',
    ];
    $paramSet['Ранг']=[
        '-'=>'0.1',
        'вузовский'=>'0.2',
        'муниципальный'=>'0.3',
        'региональный'=>'0.4',
        'всероссийский'=>'0.5',
        'международный'=>'0.6',
    ];

    $paramSet['Результат']=[
        '-'=>'1',
        'сертификат'=>'2',
        'диплом'=>'5',
        'грамота'=>'3',
        'свидетельство'=>'3',
        'благодарность'=>'2',
        'благодарственное письмо'=>'2',
        'публикация'=>'5',
        'медаль'=>'10',
        'запись в волонтерской книжке'=>'4',
        'справка-подтверждение'=>'4',
        'информационное письмо'=>'5',
    ];
    $mas_ffeld = [];
    foreach ($paramSet as $nn_l3 => $vl) {
        $cnt=1;
        foreach ($vl as $l => $p){
            $one_fel = [
                'name' => $nn_l3,
                'param' => $l,
                'setp' => $p,
                'cnt' => $cnt,
            ];
            $cnt++;
            $mas_ffeld[] = $one_fel;
        }
    }
    $user = $DB->insert_records('block_my_plugin_param', $mas_ffeld);



}

class block_my_plugin extends block_base {

    public function init() {
        $this->title = get_string('pluginname', 'block_my_plugin');
    }
    function has_config()
    {
        return true;
    }

    public function get_content() {
        global $USER, $CFG, $DB,$CFG;


        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';

        if (empty($this->instance)) {
            return $this->content;
        }

        require_once($CFG->dirroot. '/config.php');
        require_once($CFG->dirroot . '/mod/data/locallib.php');
        require_once($CFG->libdir . '/rsslib.php');
        require_once($CFG->libdir.'/completionlib.php');


        $id          = optional_param('id', 0, PARAM_INT);
        $name        = optional_param('name', '', PARAM_TEXT);
        $idnumber    = optional_param('idnumber', '', PARAM_RAW);
        $course         = optional_param('course', 0, PARAM_INT);

        $id_coorse = 0;
        $id_user = 0;
        if($course){
            $id_coorse = $course;
            $id_user = $id ;
        }else {
            $id_coorse = $id;
            $id_user = $USER->id ;
        }


        $roleassignments = $DB->get_record('role_assignments', ['userid' => $USER->id]);
     


        if(!$roleassignments || $roleassignments->roleid !=='5'){

            /*определяем его не куратор ли он*/

            if($this->check_kurator($id_coorse,$id_user )){
                //получаем список груп и студентов куратора*/
                $fe = $this->list_group($id_coorse,$id_user);
                $this->content->text .= $fe;

            }else{
                if($course){
                    $this->rating_s($id_coorse,$id_user );
                }
            }

            }else{

                if($id_coorse){
                    $this->rating_s($id_coorse,$id_user );
                }

            }

        return $this->content;
    }
    public function list_group($id_coorse,$id_user){
        global $USER, $CFG, $DB,$CFG;
        $sql_user = "SELECT T2.userid,T1.groupid,T2.courseid,T2.firstname,T2.lastname, T2.name FROM (SELECT gm.groupid, gm.userid, gm.id AS gmid FROM mdl_groups_members gm, mdl_groups g WHERE gm.userid = :userid AND g.name ='_Кураторы' AND g.courseid =:courseid) T1, (SELECT g.courseid, g.id, g.name, gm.userid, u.firstname, u.lastname, u.id as urid FROM mdl_groups_members gm, mdl_groups g, mdl_user u WHERE gm.groupid = g.id AND gm.userid = u.id AND g.name != '_Кураторы' AND g.courseid =:courseid2 ) T2 WHERE T1.groupid = T2.id AND T1.userid != T2.urid ORDER BY T1.groupid, T1.gmid";
        $param_user = ['courseid' => ''.$id_coorse,'courseid2' => ''.$id_coorse, 'userid' => ''.$id_user];
        //пользователь и курс 1 3

        $allrecordids = $DB->get_records_sql($sql_user, $param_user);


        $html_list ='';
        $mas_grp=[];
       foreach ($allrecordids as $fieldrecord => $one_gr) {

               if(array_key_exists($one_gr->name, $mas_grp)){
                   $mas_grp[$one_gr->name] .= '<div class="name-list-gr">
                                                <div class="user-gr" data-user="'.$one_gr->userid.'" data-cours="'.$one_gr->courseid.'">
                                                    <h4>'.$one_gr->firstname.' '.$one_gr->lastname.'</h4>
                                                    <div class="rating-gr">
                                                        
                                                     </div>
                                                </div>
                                              </div>';
               }else{
                   $mas_grp[$one_gr->name]='<div class="one-list-gr">
                            <h3>'.$one_gr->name.'</h3>
                            <div class="name-list-gr">
                                <div class="user-gr" data-user="'.$one_gr->userid.'" data-cours="'.$one_gr->courseid.'">
                                    <h4>'.$one_gr->firstname.' '.$one_gr->lastname.'</h4>
                                    <div class="rating-gr">
                                       
                                    </div>
                                </div>
                            </div>';

               };

       }
       foreach ($mas_grp as $one_mgr =>$vl){
           $html_list .= $vl.'</div>';
       }

        $html_list = '<div class="wrap-list-group">'.$html_list.'</div>';


        return $html_list;

    }
    public function check_kurator($id_coorse,$id_user){
        global $USER, $CFG, $DB,$CFG;
        $sql_user = "SELECT g.courseid, g.id, g.name, gm.userid, u.firstname, u.lastname FROM {groups_members} gm, mdl_groups g, {user} u WHERE gm.groupid = g.id AND gm.userid = u.id AND g.name = '_Кураторы' AND g.courseid =:courseid AND gm.userid =:userid";
        $param_user = ['courseid' => ''.$id_coorse, 'userid' => ''.$id_user]; //пользователь и курс 1 3

        $allrecordids = $DB->get_record_sql($sql_user, $param_user);

        $check=false;
        if($allrecordids->name === '_Кураторы'){
            $check = true;
        }

        return $check;
    }
    public function rating_s($id_coorse,$id_user ){
        static $fields = array();
        global $USER, $CFG, $DB,$CFG;

        $params = array();
        if (!empty($name)) {
            $params = array('shortname' => $name);
        } else if (!empty($idnumber)) {
            $params = array('idnumber' => $idnumber);
        } else if (!empty($id_coorse)) {
            $params = array('id' => $id_coorse);
        }else {
            print_error('unspecifycourseid', 'error');
        }


        $course = $DB->get_record('course', $params, '*', MUST_EXIST);
        $modinfo = get_fast_modinfo($course);
        $dat_curs = $modinfo->instances['data'];


        /*сдесь цикл подкурсов их 5 в портфолио*/
        foreach ($dat_curs as $one_curs) {
            $sql_user = 'SELECT  DISTINCT r.id, r.approved, r.timecreated, r.timemodified, r.userid, r.groupid, r.dataid, u.picture,u.firstname,u.lastname,u.firstnamephonetic,u.lastnamephonetic,u.middlename,u.alternatename,u.imagealt,u.email FROM {data_content} c,{data_records} r, {user} u   WHERE c.recordid = r.id
                         AND r.dataid = :dataid
                         AND r.userid = u.id
                         AND r.userid = :userid 
                         ORDER BY r.timecreated ASC, r.id ASC
    ';
            $param_user = ['dataid' => ''.$one_curs->instance, 'userid' => ''.$id_user]; //пользователь и курс 1 3

            $allrecordids = $DB->get_records_sql($sql_user, $param_user, 0, 0);

            $data = $DB->get_record('data', array('id' => ''.$one_curs->instance));
            $fields=[];
            $rating = ['Ранг'=>[],'Тип'=>[],'Результат'=>[]];

            if (empty($fields)) {

                $fieldrecords = $DB->get_records('data_fields', array('dataid' => '' . $param_user['dataid']));

          


                /*получаем параметры*/
                $type_sql = "SELECT * FROM {block_my_plugin_param} WHERE name='Ранг'";
                $get = $DB ->get_records_sql($type_sql);
                foreach ($get as $one_gt => $pl){
                    $rating['Ранг'][mb_strtolower($pl->param)] = $pl->setp;
                }

                $type_sql = "SELECT * FROM {block_my_plugin_param} WHERE name='Тип'";
                $get = $DB ->get_records_sql($type_sql);
                foreach ($get as $one_gt => $pl){
                    $rating['Тип'][mb_strtolower($pl->param)] = $pl->setp;
                }

                $type_sql = "SELECT * FROM {block_my_plugin_param} WHERE name='Результат'";
                $get = $DB ->get_records_sql($type_sql);
                foreach ($get as $one_gt => $pl){
                    $rating['Результат'][mb_strtolower($pl->param)] = $pl->setp;
                }



                foreach ($fieldrecords as $fieldrecord) {

                    $fields[] = data_get_field($fieldrecord, $data);
                }
            }

            $param_curse = [];
            $surs_in2 = 1;
            $all_curs[$one_curs->name]=[];
            foreach ($allrecordids as $record) {   // Might be just one for the single template
                $search = '';
                foreach ($fields as $field) {
                    $param_curse[$field->field->name] = highlight($search, $field->display_browse_field($record->id, 'singletemplate'));
                }

                $all_curs[$one_curs->name][$surs_in2]['param'] = $param_curse;

                $all_curs[$one_curs->name][$surs_in2]['name'] = $one_curs->name;

                /*рейтинг за курс*/
                $rang = $all_curs[$one_curs->name][$surs_in2]['param']['Ранг'];
                $rez = $all_curs[$one_curs->name][$surs_in2]['param']['Результат'];
                $typ = $all_curs[$one_curs->name][$surs_in2]['param']['Тип'];

                $cenka = $all_curs[$one_curs->name][$surs_in2]['param']['Оценка'];

                /*----Ранг-------------*/
                if($rang===''){
                    $rang='-';
                    $rang_cs = $rating['Ранг'][mb_strtolower($rang)];
                    if($rang_cs===null){
                        $rang_cs =1;
                    }
                }else if($rang===null){
                    $rang_cs = 1;
                }else{
                    $rang_cs = $rating['Ранг'][mb_strtolower($rang)];
                    if($rang_cs===null){
                        $rang_cs =1;
                    }
                }

                /*--Тип---------------*/
                if($typ===''){
                    $typ='-';
                    $typ_cs = $rating['Тип'][mb_strtolower($typ)];
                    if($typ_cs===null){
                        $typ_cs =1;
                    }
                }else if($typ===null){
                    $typ_cs = 1;
                }else{
                    $typ_cs = $rating['Тип'][mb_strtolower($typ)];
                    if($typ_cs===null){
                        $typ_cs = 1;
                    }
                }

                /*--Результат---------------*/
                if($rez===''){
                    $rez='-';
                    $rez_cs = $rating['Результат'][mb_strtolower($rez)];
                    if($rez_cs===null){
                        $rez_cs =1;
                    }
                }else if($rez===null){
                    $rez_cs = 1;
                }else{
                    $rez_cs = $rating['Результат'][mb_strtolower($rez)];
                    if($rez_cs===null){
                        $rez_cs = 1;
                    }
                }

                if($cenka===null || !$cenka || $cenka==='' || $cenka==='-' || $cenka==='0'){
                    $cenka=1;
                }

                $all_curs[$one_curs->name][$surs_in2]['rating_a'] = $rang_cs * $typ_cs * $rez_cs *
                    $cenka;

                $surs_in2++;
            }
            /*считеам общий за один курс*/
            $r_n=0;
            foreach ( $all_curs[$one_curs->name] as $one_c){
                $r_n += $one_c['rating_a'];
            }
            $all_curs[$one_curs->name]['rating_one'] = $r_n;
        }

        /*считаем общий рейтинг*/
        $al_eiting = 0;
        $cnt_curs =1;
        $text_rating ='';

        foreach ($all_curs as $next => $vl){
            $al_eiting +=$vl['rating_one'];
            $all_curs['all_rating'] += $vl['rating_one'];
            $cnt_curs++;
            $text_rating .= $next.' = '. $vl['rating_one'].'<br>';

        }
        $all_curs['all_rating'] =  ceil($all_curs['all_rating']*10)/10;


        $this->content->text   .=  '<div class="my_plugin">';
        $this->content->text   .=  $text_rating;
        $this->content->text   .=  '<p> Общий рейтинг = '. $all_curs['all_rating'].' </p> <br>';
        $this->content->text   .=  '<div>';

    }

}
?>
