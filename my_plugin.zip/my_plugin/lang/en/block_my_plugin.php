<?php
/*
 * @package    block_my_plugin
 */


$string['pluginname'] = 'Рейтинг студента';
$string['my_plugin'] = 'Рейтинг студента';
$string['text1'] = 'Настройки для типов работ';
$string['text2'] = 'Настройки для рангов работ';
$string['text3'] = 'Настройки для результатов работ';
$string['my_plugin:addinstance'] = 'Add a new block about rating';
$string['my_plugin:myaddinstance'] = 'Add a new block about rating to the My Moodle page';

$string['field/mark_description']='описание типа';
$string['field/rank_description']='описание ранга';
$string['field/result_description']='описание результатов';
$string['field/mark_header']='header типа';
$string['field/rank_header']='header ранга';
$string['field/result_header']='header ранга';
