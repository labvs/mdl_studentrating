
$(document).on('click','.one-list-gr h3',function () {

    var par = $(this).parents('.one-list-gr');
    if(!$('.name-list-gr',par).hasClass('active')){
        $('.name-list-gr',par).addClass('active');
        $('.name-list-gr',par).slideDown();
    }else {
        $('.name-list-gr',par).removeClass('active');
        $('.name-list-gr',par).slideUp();
    }

});
$(document).on('click','.user-gr h4',function () {

    var par = $(this).parents('.user-gr');
    if(!$(par).hasClass('anim-load')){


        if(!$('.rating-gr',par).hasClass('active')){
            $('.rating-gr',par).addClass('active');

            $('.rating-gr',par).slideDown();
        }else {
            $('.rating-gr',par).removeClass('active');
            $('.rating-gr',par).slideUp();
        }
        var userid = $(par).attr('data-user');
        var coursid = $(par).attr('data-cours');
        if(!$(par).hasClass('loading')){
            $(par).addClass('loading');
            $(par).addClass('anim-load');
            $.ajax({

                type: 'POST',

                url: '../blocks/my_plugin/jstudent.php',
                data: {
                    action:'user_rating',
                    user_id_ajx: userid,
                    cours_id_ajx: coursid,
                },
                dataType:'text',
                success: function (data) {
                    $(par).removeClass('anim-load');
                    if(data!==''){
                        $('.rating-gr',par).append(data);
                    }else {
                        $('.rating-gr',par).append('');
                        $(par).removeClass('loading');
                    }

                }
            })
        }

    }
});
